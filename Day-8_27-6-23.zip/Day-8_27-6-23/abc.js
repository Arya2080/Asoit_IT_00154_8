let n1=20,n2=30;

var sum=n1+n2,
mul=n1*n2,
sub=n1-n2,
div=n1/n2,
mod=n1%n2;
var power=5**2; 
document.write("<br/>sum:",sum+"<br/>mul:",mul+"<br />sub:",sub+"<br />div:",div+"<br />modulo:",mod+"<br />POst inc:",n++ +"<br />Post Dec:",n1-- +""<br />pre inc:",++n1+""<br />pre dec:",--n1""<br />exp:",power);